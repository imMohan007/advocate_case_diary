// Notification System
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.id = 'notification';
    notification.className = type;
    notification.textContent = message;
    document.body.appendChild(notification);
    notification.style.display = 'block';
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-in';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Simple hash function for demo (use bcrypt in production)
function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = ((hash << 5) - hash) + str.charCodeAt(i);
        hash |= 0;
    }
    return hash.toString();
}

// Authentication
function login(username, password) {
    try {
        if (!username || !password) throw new Error('Username and password are required');
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        if (users[username] && users[username].password === simpleHash(password)) {
            localStorage.setItem('currentUser', username);
            window.location.href = 'dashboard.html';
        } else {
            throw new Error('Invalid credentials');
        }
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

function register(username, password) {
    try {
        if (!username || !password) throw new Error('Username and password are required');
        if (password.length < 6) throw new Error('Password must be at least 6 characters');
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        if (users[username]) throw new Error('Username already exists');
        users[username] = { 
            password: simpleHash(password), 
            data: { clients: [], cases: [], appointments: [], courts: [], fees: [], settings: {} } 
        };
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUser', username);
        showNotification('Registration successful');
        window.location.href = 'dashboard.html';
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'login.html';
}

// Data Management
function getUserData() {
    const username = localStorage.getItem('currentUser');
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    return users[username]?.data || { clients: [], cases: [], appointments: [], courts: [], fees: [], settings: {} };
}

function saveUserData(data) {
    const username = localStorage.getItem('currentUser');
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    users[username].data = data;
    localStorage.setItem('users', JSON.stringify(users));
}

// Theme Application
function applyTheme(theme) {
    if (theme === 'dark') {
        document.body.classList.add('dark');
        document.querySelectorAll('form, th, td').forEach(el => el.classList.add('dark'));
    } else {
        document.body.classList.remove('dark');
        document.querySelectorAll('form, th, td').forEach(el => el.classList.remove('dark'));
    }
}

// Form Validation
function validateForm(fields) {
    for (const [key, value] of Object.entries(fields)) {
        if (key.includes('required') && !value) {
            throw new Error(`${key.replace('required_', '')} is required`);
        }
        if (key === 'amount' && value <= 0) {
            throw new Error('Amount must be positive');
        }
    }
}

// Helper Functions
function populateSelect(selectId, items, displayField) {
    const select = document.getElementById(selectId);
    select.innerHTML = '<option value="">Select</option>';
    items.forEach(item => {
        const option = document.createElement('option');
        option.value = item.id;
        option.textContent = item[displayField];
        select.appendChild(option);
    });
}

function updateArray(key, item, id) {
    const data = getUserData();
    if (id) {
        const index = data[key].findIndex(i => i.id === id);
        if (index !== -1) data[key][index] = item;
    } else {
        data[key].push(item);
    }
    saveUserData(data);
    loadTable(`${key.slice(0, -1)}Table`, data[key], Object.keys(item).filter(k => k !== 'id'), getFormatters(key));
    showNotification(id ? `${key.slice(0, -1)} updated` : `${key.slice(0, -1)} added`);
}

function getFormatters(key) {
    const data = getUserData();
    if (key === 'cases' || key === 'appointments') {
        return { client_id: (id) => data.clients.find(c => c.id === id)?.name || 'N/A' };
    } else if (key === 'fees') {
        return { paid: (val) => val ? 'Yes' : 'No', case_id: (id) => data.cases.find(c => c.id === id)?.title || 'N/A' };
    }
    return {};
}

function loadTable(tableId, items, fields, formatters = {}) {
    const table = document.getElementById(tableId);
    table.innerHTML = '';
    items.forEach(item => {
        const row = document.createElement('tr');
        fields.forEach(field => {
            const cell = document.createElement('td');
            cell.textContent = formatters[field] ? formatters[field](item[field]) : item[field];
            row.appendChild(cell);
        });
        const actions = document.createElement('td');
        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.onclick = () => editItem(item, tableId.replace('Table', 'Form'));
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = () => deleteItem(item.id, tableId);
        actions.appendChild(editButton);
        actions.appendChild(deleteButton);
        row.appendChild(actions);
        table.appendChild(row);
    });
}

function loadSettingsTable(tableId, settings) {
    const table = document.getElementById(tableId);
    table.innerHTML = '';
    Object.entries(settings).forEach(([key, value]) => {
        const row = document.createElement('tr');
        row.innerHTML = `<td>${key}</td><td>${value}</td>`;
        const actions = document.createElement('td');
        const editButton = document.createElement('button');
        editButton.textContent = 'Edit';
        editButton.onclick = () => {
            if (key === 'notifications') {
                document.getElementById('notifications').checked = value === 'enabled';
            } else {
                document.getElementById(key).value = value;
            }
        };
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = () => {
            const data = getUserData();
            delete data.settings[key];
            saveUserData(data);
            loadSettingsTable(tableId, data.settings);
            showNotification('Setting deleted');
        };
        actions.appendChild(editButton);
        actions.appendChild(deleteButton);
        row.appendChild(actions);
        table.appendChild(row);
    });
}

function editItem(item, formId) {
    Object.keys(item).forEach(key => {
        const inputId = formId.replace('Form', key.charAt(0).toUpperCase() + key.slice(1));
        const input = document.getElementById(inputId);
        if (input) {
            if (input.type === 'checkbox') {
                input.checked = item[key];
            } else {
                input.value = item[key];
            }
        }
    });
    document.getElementById('submitButton').value = 'Update';
}

function deleteItem(id, tableId) {
    const key = tableId.replace('Table', 's').toLowerCase();
    const data = getUserData();
    data[key] = data[key].filter(item => item.id !== id);
    saveUserData(data);
    loadTable(tableId, data[key], Object.keys(data[key][0] || {}).filter(k => k !== 'id'), getFormatters(key));
    showNotification(`${key.slice(0, -1)} deleted`);
}

// Page-specific Logic
document.addEventListener('DOMContentLoaded', () => {
    const username = localStorage.getItem('currentUser');
    if (!username && !['login.html', 'register.html'].includes(window.location.pathname.split('/').pop())) {
        window.location.href = 'login.html';
        return;
    }

    const data = getUserData();
    applyTheme(data.settings.theme || 'light');

    if (document.getElementById('username')) {
        document.getElementById('username').textContent = username;
    }

    // Login Form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            login(document.getElementById('username').value, document.getElementById('password').value);
        });
    }

    // Register Form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            register(document.getElementById('username').value, document.getElementById('password').value);
        });
    }

    // Clients Form
    const clientForm = document.getElementById('clientForm');
    if (clientForm) {
        loadTable('clientTable', data.clients, ['name', 'contact', 'address']);
        clientForm.addEventListener('submit', (e) => {
            e.preventDefault();
            try {
                validateForm({ required_name: document.getElementById('clientName').value });
                const id = document.getElementById('clientId').value;
                const item = {
                    id: id || Date.now().toString(),
                    name: document.getElementById('clientName').value,
                    contact: document.getElementById('clientContact').value,
                    address: document.getElementById('clientAddress').value
                };
                updateArray('clients', item, id);
                clientForm.reset();
                document.getElementById('submitButton').value = 'Add Client';
            } catch (error) {
                showNotification(error.message, 'error');
            }
        });
    }

    // Cases Form
    const caseForm = document.getElementById('caseForm');
    if (caseForm) {
        populateSelect('caseClientId', data.clients, 'name');
        loadTable('caseTable', data.cases, ['title', 'description', 'status', 'client_id'], getFormatters('cases'));
        caseForm.addEventListener('submit', (e) => {
            e.preventDefault();
            try {
                validateForm({ 
                    required_title: document.getElementById('caseTitle').value,
                    required_client_id: document.getElementById('caseClientId').value
                });
                const id = document.getElementById('caseId').value;
                const item = {
                    id: id || Date.now().toString(),
                    title: document.getElementById('caseTitle').value,
                    description: document.getElementById('caseDescription').value,
                    status: document.getElementById('caseStatus').value,
                    client_id: document.getElementById('caseClientId').value
                };
                updateArray('cases', item, id);
                caseForm.reset();
                document.getElementById('submitButton').value = 'Add Case';
            } catch (error) {
                showNotification(error.message, 'error');
            }
        });
    }

    // Appointments Form
    const appointmentForm = document.getElementById('appointmentForm');
    if (appointmentForm) {
        populateSelect('appointmentClientId', data.clients, 'name');
        loadTable('appointmentTable', data.appointments, ['date', 'time', 'description', 'client_id'], getFormatters('appointments'));
        appointmentForm.addEventListener('submit', (e) => {
            e.preventDefault();
            try {
                validateForm({ 
                    required_date: document.getElementById('appointmentDate').value,
                    required_client_id: document.getElementById('appointmentClientId').value
                });
                const id = document.getElementById('appointmentId').value;
                const item = {
                    id: id || Date.now().toString(),
                    date: document.getElementById('appointmentDate').value,
                    time: document.getElementById('appointmentTime').value,
                    description: document.getElementById('appointmentDescription').value,
                    client_id: document.getElementById('appointmentClientId').value
                };
                updateArray('appointments', item, id);
                appointmentForm.reset();
                document.getElementById('submitButton').value = 'Add Appointment';
            } catch (error) {
                showNotification(error.message, 'error');
            }
        });
    }

    // Courts Form
    const courtForm = document.getElementById('courtForm');
    if (courtForm) {
        loadTable('courtTable', data.courts, ['name', 'location']);
        courtForm.addEventListener('submit', (e) => {
            e.preventDefault();
            try {
                validateForm({ required_name: document.getElementById('courtName').value });
                const id = document.getElementById('courtId').value;
                const item = {
                    id: id || Date.now().toString(),
                    name: document.getElementById('courtName').value,
                    location: document.getElementById('courtLocation').value
                };
                updateArray('courts', item, id);
                courtForm.reset();
                document.getElementById('submitButton').value = 'Add Court Division';
            } catch (error) {
                showNotification(error.message, 'error');
            }
        });
    }

    // Fees Form
    const feeForm = document.getElementById('feeForm');
    if (feeForm) {
        populateSelect('feeCaseId', data.cases, 'title');
        loadTable('feeTable', data.fees, ['amount', 'description', 'paid', 'case_id'], getFormatters('fees'));
        feeForm.addEventListener('submit', (e) => {
            e.preventDefault();
            try {
                validateForm({ 
                    required_amount: document.getElementById('feeAmount').value,
                    amount: parseFloat(document.getElementById('feeAmount').value),
                    required_case_id: document.getElementById('feeCaseId').value
                });
                const id = document.getElementById('feeId').value;
                const item = {
                    id: id || Date.now().toString(),
                    amount: parseFloat(document.getElementById('feeAmount').value),
                    description: document.getElementById('feeDescription').value,
                    paid: document.getElementById('feePaid').checked,
                    case_id: document.getElementById('feeCaseId').value
                };
                updateArray('fees', item, id);
                feeForm.reset();
                document.getElementById('submitButton').value = 'Add Fee';
            } catch (error) {
                showNotification(error.message, 'error');
            }
        });
    }

    // Settings Form
    const settingForm = document.getElementById('settingForm');
    if (settingForm) {
        document.getElementById('notifications').checked = data.settings.notifications === 'enabled';
        document.getElementById('currency').value = data.settings.currency || 'USD';
        document.getElementById('theme').value = data.settings.theme || 'light';
        loadSettingsTable('settingTable', data.settings);
        settingForm.addEventListener('submit', (e) => {
            e.preventDefault();
            try {
                const settings = {
                    notifications: document.getElementById('notifications').checked ? 'enabled' : 'disabled',
                    currency: document.getElementById('currency').value,
                    theme: document.getElementById('theme').value
                };
                const data = getUserData();
                data.settings = settings;
                saveUserData(data);
                loadSettingsTable('settingTable', settings);
                applyTheme(settings.theme);
                showNotification('Settings saved');
            } catch (error) {
                showNotification(error.message, 'error');
            }
        });
    }
});